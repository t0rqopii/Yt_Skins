/* Companion is isolated from YouTube's styles and only its button receives clicks. */
(() => {
  let host, image, timer;
  function update(value) {
    const s = ThemeStudio.normalize(value);
    if (!s.enabled || !s.companionEnabled || !s.companionImage) { if (host) host.remove(); host = image = null; clearTimeout(timer); return; }
    if (!host) {
      host = document.createElement('div');
      const shadow = host.attachShadow({mode:'closed'});
      const style = document.createElement('style'); style.textContent = ':host{position:fixed;z-index:2147483000}button{display:block;padding:0;border:0;background:transparent;cursor:pointer}img{display:block;width:100%;height:auto}img.blink{transform:scaleY(.12)}@media(prefers-reduced-motion:reduce){img.blink{transform:none}}';
      const button = document.createElement('button'); button.type = 'button'; button.setAttribute('aria-label','Wink companion'); image = document.createElement('img'); image.alt = ''; button.append(image); shadow.append(style,button);
      button.addEventListener('click', () => { clearTimeout(timer); if (host._wink) image.src = host._wink; else image.classList.add('blink'); timer = setTimeout(() => { if (image && host) { image.src = host._rest; image.classList.remove('blink'); } }, 240); });
      (document.body || document.documentElement).append(host);
    }
    host.style.cssText = `position:fixed;${s.companionSide}:12px;bottom:${s.companionOffset}%;width:${s.companionSize}px;z-index:2147483000`;
    host._rest = s.companionImage; host._wink = s.companionWink; image.src = s.companionImage;
  }
  ThemeState.subscribe((state, keys) => { if (keys.includes('theme')) update(state.theme); });
})();
